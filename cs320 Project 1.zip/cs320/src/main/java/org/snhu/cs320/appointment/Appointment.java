package org.snhu.cs320.appointment;

//import java.time.LocalDate;

import org.snhu.cs320.exceptions.ValidationException;
import org.snhu.cs320.validation.Validation;

public class Appointment {

	private String id;
	//private String date;
	private String description;
	
	public Appointment(String id, String description) {
		super();
		this.id = id;
		//this.date = date;
		this.description = description;
		
		validate();
	}
	

	public void validate() {
		// ID field
		Validation.validateNotNull(id, "id");
		Validation.validateNotBlank(id, "id");
		Validation.validateLength(id, "id", 1, 10);
		
		// Date
		//Validation.validateNotNull(date, "date");
		//Validation.validateNotNull(date, "date");
		//Validation.validateIsPresentOrFuture(date, "date");
		
		// Description
		Validation.validateNotNull(description, "description");
		Validation.validateNotBlank(description, "description");
		Validation.validateLength(description, "description", 1, 50);
		
	}
	
	//public String getDate() {
		//return date;
	//}
	//public void setDate(String date) {
		//this.date = date;
	//}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getId() {
		return id;
	}

	
	
	
	
}
