package org.snhu.cs320.task;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;

public class TaskServiceTest {
	
	@BeforeEach
	void init() {
		TaskService.TASK_DATABASE.clear();
	}
	
	@Test
	void addSuccess() {
		Task task = new Task("12345", "FullName", "22 Acacia Avenue");
		assertThat(TaskService.add(task)).isTrue();
		assertThat(TaskService.TASK_DATABASE).containsEntry("12345", task);
	}
	
	@Test
	void addExistingId() {
		Task task = new Task("12345", "FullName", "22 Acacia Avenue");
		assertThat(TaskService.add(task)).isTrue();
		assertThat(TaskService.add(task)).isFalse();
	}
	
	@Test
	void deleteSuccess() {
		Task task = new Task("12345", "FullName", "22 Acacia Avenue");
		assertThat(TaskService.add(task)).isTrue();
		assertThat(TaskService.delete("12345")).isTrue();
		assertThat(TaskService.TASK_DATABASE).doesNotContainKey("12345");
	}
	
	@Test
	void deleteNonExisting() {
		assertThat(TaskService.delete("12345")).isFalse();
	}
	
	@Test
	void updateSuccess() {
		Task task = new Task("12345", "FullName", "22 Acacia Avenue");
		assertThat(TaskService.add(task)).isTrue();
		
		Task updated = new Task("12345", "FullName", "22 Arcadia Avenue");
		assertThat(TaskService.update("12345", updated)).isTrue();
		
		assertThat(TaskService.TASK_DATABASE)
			.extracting("12345")
			.hasFieldOrPropertyWithValue("description", "22 Arcadia Avenue");
	}
	
	@Test
	void updateNonExistent() {
		Task updated = new Task("12345", "FullName", "22 Acacia Avenue");
		assertThat(TaskService.update("12345", updated)).isFalse();
	}
	
	@Test
	void updateThrowsExceptionOnInvalidData() {
		
		Task task = new Task("12345", "FullName", "22 Acacia Avenue");
		assertThat(TaskService.add(task)).isTrue();

	}
}