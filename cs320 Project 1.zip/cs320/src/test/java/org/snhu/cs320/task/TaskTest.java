package org.snhu.cs320.task;

import static org.assertj.core.api.Assertions.assertThat; 
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.snhu.cs320.exceptions.ValidationException;

public class TaskTest {

	@Test
	void testHappyPath() {
		Task task = new Task("1", "FullName", "22 Acacia Avenue");
		assertThat(task)
			.isNotNull()
			.hasFieldOrPropertyWithValue("id",  "1")
			.hasFieldOrPropertyWithValue("name",  "FullName")
			.hasFieldOrPropertyWithValue("description", "22 Acacia Avenue");
	}
	
	@ParameterizedTest
	@CsvSource({
		"'',FullName, 22 Acacia Avenue", // Blank ID
		",FullName,22 Acacia Avenue", // Null ID
		"12345678901,FullName,22 Acacia Avenue", // ID is too long
		
		"1,'',22 Acacia Avenue", // Blank Name
		"1,,22 Acacia Avenue", // Null Name
		"1,namenamenamenamenamename, 22 Acacia Avenue", // Too Long Name
		
		"1,FullName,''", // Blank description
		"1,FullName,,", // Null description
		"1,FullName,22 Acacia Avenue 22 Acacia Avenue 22 Acacia Avenue 22 Acacia Avenue", // Too Long description
	})
	void invalidInputThrowsException(String id, String name, String description) {
		assertThatThrownBy(() -> new Task(id, name, description))
			.isInstanceOf(ValidationException.class);
	}
}
