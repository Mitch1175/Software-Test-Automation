package org.snhu.cs320.appointment;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.snhu.cs320.exceptions.ValidationException;

public class AppointmentServiceTest {
	
	@BeforeEach
	void init() {
		AppointmentService.APPOINTMENT_DATABASE.clear();
	}
	
	@Test
	void addSuccess() {
		Appointment appointment = new Appointment("12345", "This is a test");
		assertThat(AppointmentService.add(appointment)).isTrue();
		assertThat(AppointmentService.APPOINTMENT_DATABASE).containsEntry("12345", appointment);
	}
	
	@Test
	void addExistingId() {
		Appointment appointment = new Appointment("12345", "This is a test");
		assertThat(AppointmentService.add(appointment)).isTrue();
		assertThat(AppointmentService.add(appointment)).isFalse();
	}
	
	@Test
	void deleteSuccess() {
		Appointment appointment = new Appointment("12345", "This is a test");
		assertThat(AppointmentService.add(appointment)).isTrue();
		assertThat(AppointmentService.delete("12345")).isTrue();
		assertThat(AppointmentService.APPOINTMENT_DATABASE).doesNotContainKey("12345");
	}
	
	@Test
	void deleteNonExisting() {
		assertThat(AppointmentService.delete("12345")).isFalse();
	}
}
	