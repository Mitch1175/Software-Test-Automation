package org.snhu.cs320.appointment;

import static org.assertj.core.api.Assertions.assertThat; 
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.Date;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.snhu.cs320.exceptions.ValidationException;

public class AppointmentTest {

	@Test
	void testApptPath() {
		Appointment appointment = new Appointment("1", "This is a test");
		assertThat(appointment)
			.isNotNull()
			.hasFieldOrPropertyWithValue("id",  "1")
			.hasFieldOrPropertyWithValue("description", "This is a test");
	}
	
	/*
	@Test
    void testAppointmentDate() {
       final Date now = new Date();
       final Appointment appointment = new Appointment("1", "Appointment 1", now());

       assertEquals(now, appointment.appointmentDate());
    }
	*/

	@ParameterizedTest
	@CsvSource({
		"'',This is a test", // Blank ID
		",This is a test", // Null ID
		"12345678901,date,This is a test", // ID is too long
		
		//"1,'',This is a test", // Blank Date
		//"1,,This is a test", // Null Date
		//"1,date,This is a test", // Too Long Name
		
		"1,''", // Blank description
		"1,", // Null description
		"1,This is a test This is a test This is a test This is a test This is a test", // Too Long description
	})
	void invalidInputThrowsException(String id, String description) {
		assertThatThrownBy(() -> new Appointment(id, description))
			.isInstanceOf(ValidationException.class);
	}
}